package xjtutjc.service;

public interface UserAdd {
}
