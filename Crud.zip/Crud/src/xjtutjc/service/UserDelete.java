package xjtutjc.service;

public interface UserDelete {
    public void userDelete();
}
